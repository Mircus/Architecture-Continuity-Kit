"""Stable core domain."""
