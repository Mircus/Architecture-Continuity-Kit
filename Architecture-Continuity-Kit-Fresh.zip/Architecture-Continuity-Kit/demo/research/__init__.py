"""Research component."""
