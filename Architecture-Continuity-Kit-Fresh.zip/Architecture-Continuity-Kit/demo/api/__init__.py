"""API-facing component."""
