## Change in one sentence
What changed and why?

## Architectural impact
- Components touched:
- Added/removed dependencies:
- Does `architecture.toml` or a decision record need updating? Why?

## Evidence
- Automated tests run and outcomes (paste actual command/results):
- Runtime trace / manual test, if relevant:
- What remains inferred or untested?

## Risk and rollback
- Critical invariant at risk:
- How would we reverse this change?

## Continuity
- What should the next collaborator or AI agent know?
- Should `docs/PROJECT_STATE.md` change?
